import { Component } from '@angular/core';
import { DepartamentoService } from '../services/departamento/departamento.service';
import { HttpClient } from '@angular/common/http';
import { Router } from 'express';

@Component({
  selector: 'app-editar',
  standalone: false,
  templateUrl: './editar.component.html',
  styleUrl: './editar.component.css'
})
export class EditarComponent {
  departamento: any[]=[];

  constructor(
    private departamentoService: DepartamentoService,
    private http: HttpClient,
    private router: Router
  ){};

  ngOnInit(): void{
    this.departamentoService.findDepartamentoByID().subscribe();
  }
}
